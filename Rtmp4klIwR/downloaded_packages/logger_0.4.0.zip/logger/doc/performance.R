## ----cleanup, include = FALSE-------------------------------------------------
logger:::namespaces_reset()

