# cols4all 0.8
- main table much faster
- sorting and filtering options added
- powerbi and matplotlib palettes added
- [!] added new "cols4all" categorical palettes
- analysis tabs updated

# cols4all 0.7-1
- fixed critical bug in c4a_gui

# cols4all 0.7
- improved similarity matrix plot
- improved applications tab
- added naming column (in development)
- added new 'tol' palettes
- scores shown with more precision
- compatibility with tmap 4.0

# cols4all 0.6-1
- fixed bug confusion lines

# cols4all 0.6
- first CRAN release
